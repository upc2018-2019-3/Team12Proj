﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;

public partial class Buy_New : WebPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        this.ValidatePopedom("管理员");        
        if (!this.IsPostBack)
        {
            this.hidBuyID.Value = Request.QueryString["BuyID"] + "";
            this.initList();
        }
    }

    #region 事件产生的函数
    protected void btnOK_Click(object sender, EventArgs e)
    {
        BuyMgr mgr = new BuyMgr();
        Buy buy = new Buy();
        HouseMgr hMgr = new HouseMgr();
        if (this.hidBuyID.Value != "")
        {
            buy = mgr.GetBuy(this.hidBuyID.Value);
        }

        buy.PersonName = this.txtPersonName.Text;
        buy.Card = this.txtCard.Text;
        buy.Address = this.txtAddress.Text;
        buy.House.HouseID = this.lstHouseID.SelectedValue;
        buy.House.HouseStatus.HouseStatusID = 3;
        hMgr.UpdateHouse(buy.House);
        buy.Deposit = int.Parse(this.txtDeposit.Text.Trim());
        buy.HouseDate = DateTime.Now;

        mgr.UpdateBuy(buy);
        if (this.hidBuyID.Value == "")
        {
            this.ClearTextData(this);
        }
        this.SendMessage("信息编辑成功");

    }
    #endregion

    #region 窗体内部函数
        /// <summary>
    /// 初始化下拉列表
    /// </summary>
    private void initList()
    {
        HouseMgr hMgr = new HouseMgr();
        this.lstHouseID.DataSource = hMgr.GetHouseList("", -1, 1);
        this.lstHouseID.DataTextField = "HouseID";
        this.lstHouseID.DataValueField = "HouseID";
        this.lstHouseID.DataBind();
    }
    #endregion

}
