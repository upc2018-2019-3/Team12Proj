﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;

public partial class Hotel_Edit : WebPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        this.ValidatePopedom("管理员");        
        if (!this.IsPostBack)
        {
            this.initList();
            this.txtHouseID.Text = Request.QueryString["HouseID"] + "";
            if (this.txtHouseID.Text != "")
            {
                this.txtHouseID.Enabled = false;
            }
            this.initForm();
        }
    }

    #region 事件产生的函数
    protected void btnOK_Click(object sender, EventArgs e)
    {
        if (this.ValidateData())
        {
            House house = new House();
            HouseMgr mgr = new HouseMgr();

            house.HouseID = this.txtHouseID.Text.Trim();
            house.HouseName = this.txtHouseName.Text;
            house.Price = int.Parse(this.txtPrice.Text);
            house.HouseType.HouseTypeID = int.Parse(this.lstHouseTypeID.SelectedValue);
            house.HouseStatus.HouseStatusID = int.Parse(this.lstHouseStatusID.SelectedValue);


            mgr.UpdateHouse(house);
            this.SendMessage("信息编辑成功");
            if (this.txtHouseID.Enabled)
            {
                this.ClearTextData(this);
            }
        }
    }
    #endregion

    #region 窗体内部函数
    /// <summary>
    /// 初始化下拉列表
    /// </summary>
    private void initList()
    {
        HouseTypeMgr htMgr = new HouseTypeMgr();
        this.lstHouseTypeID.DataSource = htMgr.GetHouseTypeList();
        this.lstHouseTypeID.DataTextField = "HouseTypeName";
        this.lstHouseTypeID.DataValueField = "HouseTypeID";
        this.lstHouseTypeID.DataBind();

        HouseStatusMgr hsMgr = new HouseStatusMgr();
        this.lstHouseStatusID.DataSource = hsMgr.GetHouseStatusList();
        this.lstHouseStatusID.DataTextField = "HouseStatusName";
        this.lstHouseStatusID.DataValueField = "HouseStatusID";
        this.lstHouseStatusID.DataBind();

    }

    /// <summary>
    /// 初始化窗体信息
    /// </summary>
    private void initForm()
    {
        if (!this.txtHouseID.Enabled)
        {
            HouseMgr mgr = new HouseMgr();
            House house = mgr.GetHouse(this.txtHouseID.Text);
            if (house.HouseID == "")
            {
                this.btnOK.Enabled = false;
                this.SendMessage("没有找到该房间");
            }
            else
            {
                this.txtHouseID.Text = house.HouseID;
                this.txtHouseID.Enabled = false;
                this.txtHouseName.Text = house.HouseName;
                this.txtPrice.Text = house.Price.ToString();

                if (this.lstHouseTypeID.Items.FindByValue(house.HouseType.HouseTypeID.ToString()) != null)
                {
                    this.lstHouseTypeID.ClearSelection();
                    this.lstHouseTypeID.Items.FindByValue(house.HouseType.HouseTypeID.ToString()).Selected = true;
                }

                if (this.lstHouseStatusID.Items.FindByValue(house.HouseStatus.HouseStatusID.ToString()) != null)
                {
                    this.lstHouseStatusID.ClearSelection();
                    this.lstHouseStatusID.Items.FindByValue(house.HouseStatus.HouseStatusID.ToString()).Selected = true;
                }
            }
        }
    }

    /// <summary>
    /// 验证添加的房间信息
    /// </summary>
    /// <returns>可以提交返回true否则返回false</returns>
    private bool ValidateData()
    {
        if (this.txtHouseID.Enabled == true)
        {
            HouseMgr mgr = new HouseMgr();
            if (mgr.GetHouse(this.txtHouseID.Text).HouseID != "")
            {
                this.SendMessage("该房间编号已存在");
                return false;
            }
        }
        return true;
    }
    #endregion

}
