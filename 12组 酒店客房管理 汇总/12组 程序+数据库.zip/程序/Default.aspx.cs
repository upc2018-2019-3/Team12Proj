﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class _Default : WebPage
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnLogin_Click(object sender, ImageClickEventArgs e)
    {
        AdminMgr aMgr = new AdminMgr();
        Admin admin = aMgr.GetAdmin(this.txtAdminID.Text.Trim());
        if (admin.AdminID == "")
        {
            this.SendMessage("没有找到该登录名称");
        }
        else if (admin.Password != this.txtPassword.Text)
        {
            this.SendMessage("管理员登录密码不正确");
        }
        else
        {

            this.eLoginName = this.txtAdminID.Text.Trim();
            this.eUserID = this.txtAdminID.Text.Trim();
            this.eUserName = this.txtAdminID.Text.Trim();
            this.eUserType = "管理员";
            Response.Redirect("MainFrame.aspx");
        }
    }
}
