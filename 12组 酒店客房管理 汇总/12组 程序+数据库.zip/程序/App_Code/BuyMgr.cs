using System;
using System.Data;
using System.Data.SqlClient;

/// <summary>
/// Buy������
/// </summary>
public class BuyMgr
{
	/// <summary>
	/// ��ʼ��������
	/// </summary>
	public BuyMgr()
	{
	}

	#region������UpdateBuy | ����Buy��Ϣ
	/// <summary>
	/// ����Buy����Ϣ
	/// </summary>
	/// <param name="buy">�����������</param>
	/// <returns>���³ɹ�����true ���򷵻�false</returns>
	public bool UpdateBuy(Buy buy)
	{
		string strSQL = "";
		SqlDataAdapter sa = null;
		SqlCommandBuilder builder = null;
		DataRow row = null;
		DataTable dt = null;
		bool returnValue = false;
		if (buy != null)
		{
			if (buy.BuyID == 0)
			{
				strSQL = "SELECT Top 0 * FROM ml_Buy";
			}
			else
			{
				strSQL = "SELECT * FROM ml_Buy WHERE BuyID = '" + buy.BuyID + "'";
			}

			dt = CMMgr.GetDataTable(strSQL);

			if (dt.Rows.Count > 0)
			{
				row = dt.Rows[0];
                row["ExitDate"] = DateTime.Now;
			}
			else
			{
				row = dt.NewRow();
                row["HouseDate"] = DateTime.Now;
                row["ExitDate"] = DateTime.Parse("1950-1-1");
			}

			row["PersonName"] = buy.PersonName;
            row["Card"] = buy.Card;
            row["Address"] = buy.Address;
            row["HouseID"] = buy.House.HouseID;
            row["Deposit"] = buy.Deposit;
            row["ExitPrice"] = buy.ExitPrice;

			if (dt.Rows.Count == 0)
			{
				dt.Rows.Add(row);
			}

			SqlConnection conn = CMMgr.GetConnection();
			using (sa = new SqlDataAdapter("SELECT Top 0 * FROM ml_Buy",conn))
			{
                try
                {
                    builder = new SqlCommandBuilder(sa);
                    sa.Update(dt);
                    returnValue = true;
                }
                catch { }
				finally
				{
					conn.Close();
					conn.Dispose();
				}
			}
		}
		return returnValue;
	}
	#endregion

	#region������GetBuy | ��ȡBuy��Ϣ
	/// <summary>
	/// ��ȡһ��Buy����Ϣ
	/// </summary>
	/// <param name="BuyID">���</param>
	/// <returns>һ��Buy���¼</returns>
	public Buy GetBuy(string BuyID)
	{
		Buy buy = new Buy();
        HouseMgr hMgr = new HouseMgr();
		string strSQL = "SELECT * FROM ml_Buy WHERE BuyID = '" + BuyID + "'";
		DataTable dt = CMMgr.GetDataTable(strSQL);
		if (dt.Rows.Count > 0)
		{
			DataRow row = dt.Rows[0];
			buy.BuyID = int.Parse(row["BuyID"].ToString());
			buy.PersonName = row["PersonName"].ToString();
            buy.Card = row["Card"].ToString();
            buy.Address = row["Address"].ToString();
            buy.House = hMgr.GetHouse(row["HouseID"].ToString());
            buy.Deposit = int.Parse(row["Deposit"].ToString());
            buy.HouseDate = DateTime.Parse(row["HouseDate"].ToString());
            buy.ExitDate = DateTime.Parse(row["ExitDate"].ToString());
            buy.ExitPrice = int.Parse(row["ExitPrice"].ToString());
			return buy;
		}
		else
		{
			return buy;
		}
	}

	/// <summary>
	/// ��ȡһ��Buy����Ϣ
	/// </summary>
	/// <param name="BuyID">���</param>
	/// <returns>һ��Buy���¼</returns>
	public Buy GetBuy(int BuyID)
	{
		return GetBuy(BuyID.ToString());
	}

	#endregion

	#region������DelBuy | ɾ��Buy��Ϣ
	/// <summary>
	/// ɾ��Buy����Ϣ
	/// </summary>
	/// <param name="BuyID">��Ų���</param>
	public void DelBuy(string BuyID)
	{
		string strSQL = "DELETE FROM ml_Buy WHERE BuyID = '" + BuyID + "'";
		CMMgr.ExecuteNonQuery(strSQL);
	}

	/// <summary>
	/// ɾ��Buy����Ϣ
	/// </summary>
	/// <param name="BuyID">���</param>
	public void DelBuy(int BuyID)
	{
		this.DelBuy(BuyID.ToString());
	}

	/// <summary>
	/// ɾ��Buy����Ϣ
	/// </summary>
	/// <param name="buy">Buy��</param>
	public void DelBuy(Buy buy)
	{
		this.DelBuy(buy.BuyID);
	}
	#endregion

    #region ����GetBuyList |����ȡBuy�б���Ϣ
    /// <summary>
    /// ����GetBuyList |����ȡBuy�б���Ϣ
    /// </summary>
    /// <param name="EndDate">�˷�ʱ��</param>
    /// <param name="StartDate">��סʱ��</param>
    /// <returns></returns>
    public DataTable GetBuyList(DateTime StartDate,DateTime EndDate)
    {
        string strSQL = "SELECT *,(Deposit - ExitPrice) AS SumPrice FROM ml_Buy WHERE 1=1 "
                      + "AND ((HouseDate >= Convert(datetime,'" + StartDate.ToString() + "') AND HouseDate <= Convert(datetime,'" + EndDate.ToShortDateString() + " 23:59:59')) "
                      + "OR ((ExitDate >= Convert(datetime,'" + StartDate.ToString() + "') AND ExitDate <= Convert(datetime,'" + EndDate.ToShortDateString() + " 23:59:59')))) ";
            
        return CMMgr.GetDataTable(strSQL);
    }
    #endregion

    #region ���� GetNoExitBuyList | ��ȡ����δ�˷��Ķ���
    /// <summary>
    /// ��ȡ����δ�˷��Ķ���
    /// </summary>
    /// <param name="HouseID">�����</param>
    /// <returns></returns>
    public DataTable GetNoExitBuyList(int HouseID)
    {
        string strSQL = "";
        if (HouseID != -1)
        {
            strSQL = "SELECT * FROM ml_Buy WHERE HouseID = " + HouseID + "AND ExitDate >= Convert(datetime,'" + DateTime.Parse("1950-1-1").ToString() + "') AND ExitDate <= Convert(datetime,'" + DateTime.Parse("1950-1-1").ToString() + "')";
        }
        else
        {
            strSQL = "SELECT * FROM ml_Buy WHERE ExitDate >= Convert(datetime,'" + DateTime.Parse("1950-1-1").ToString() + "') AND ExitDate <= Convert(datetime,'" + DateTime.Parse("1950-1-1").ToString() + "')";
        }
        return CMMgr.GetDataTable(strSQL);
    }
    #endregion

    /// <summary>
    /// ����GetBuyList |����ȡBuy�б���Ϣ
    /// </summary>
    /// <param name="EndDate">�˷�ʱ��</param>
    /// <param name="StartDate">��סʱ��</param>
    /// <returns></returns>
    public string GetBuySumPrice(DateTime StartDate, DateTime EndDate)
    {
        string strSQL = "SELECT SUM(Deposit - ExitPrice) AS SumPrice FROM ml_Buy WHERE 1=1 "
                      + "AND ((HouseDate >= Convert(datetime,'" + StartDate.ToString() + "') AND HouseDate <= Convert(datetime,'" + EndDate.ToShortDateString() + " 23:59:59')) "
                      + "OR ((ExitDate >= Convert(datetime,'" + StartDate.ToString() + "') AND ExitDate <= Convert(datetime,'" + EndDate.ToShortDateString() + " 23:59:59')))) ";
        DataTable dtSum = CMMgr.GetDataTable(strSQL);

        if (dtSum.Rows.Count > 0)
        {
            return dtSum.Rows[0]["SumPrice"].ToString();
        }
        else
        {
            return "0";
        }
    }
}
