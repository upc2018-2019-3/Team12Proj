using System;

/// <summary>
/// ����Ա��
/// </summary>
public class Admin
{
	private string m_AdminID;
	private string m_Password;
    private string m_UserName;
    private string m_Tel;

	/// <summary>
	/// ����Ա��
	/// </summary>
	public Admin()
	{
		this.m_AdminID = "";
		this.m_Password = "";
        this.m_UserName = "";
        this.m_Tel = "";
	}

	/// <summary>
	/// ��¼���
	/// </summary>
	public string AdminID
	{
		set
		{
			this.m_AdminID = value;
		}
		get
		{
			return this.m_AdminID;
		}
	}

	/// <summary>
	/// ��¼����
	/// </summary>
	public string Password
	{
		set
		{
			this.m_Password = value;
		}
		get
		{
			return this.m_Password;
		}
	}

    /// <summary>
    /// ��ʵ����
    /// </summary>
    public string UserName
    {
        set
        {
            this.m_UserName = value;
        }
        get
        {
            return this.m_UserName;
        }
    }

    /// <summary>
    /// ��ϵ�绰    
    /// </summary>
    public string Tel
    {
        set
        {
            this.m_Tel = value;
        }
        get
        {
            return this.m_Tel;
        }
    }
}