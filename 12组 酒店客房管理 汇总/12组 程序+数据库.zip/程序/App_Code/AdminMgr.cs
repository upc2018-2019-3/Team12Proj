using System;
using System.Data;
using System.Data.SqlClient;


/// <summary>
/// Admin������
/// </summary>
public class AdminMgr
{
	/// <summary>
	/// ��ʼ��������
	/// </summary>
	public AdminMgr()
	{
	}

	#region������UpdateAdmin | ����Admin��Ϣ
	/// <summary>
	/// ����Admin����Ϣ
	/// </summary>
	/// <param name="admin">����Ա�����</param>
	/// <returns>���³ɹ�����true ���򷵻�false</returns>
	public bool UpdateAdmin(Admin admin)
	{
		string strSQL = "";
		SqlDataAdapter sa = null;
		SqlCommandBuilder builder = null;
		DataRow row = null;
		DataTable dt = null;
		bool returnValue = false;
		if (admin != null)
		{
			if (admin.AdminID == "")
			{
				strSQL = "SELECT Top 0 * FROM ml_Admin";
			}
			else
			{
				strSQL = "SELECT * FROM ml_Admin WHERE AdminID = '" + admin.AdminID + "'";
			}

			dt = CMMgr.GetDataTable(strSQL);

			 if (dt.Rows.Count > 0)
			{
				row = dt.Rows[0];
			}
			else
			{
				row = dt.NewRow();
				row["AdminID"] = admin.AdminID;
			}
			row["Password"] = admin.Password;
            row["UserName"] = admin.UserName;
            row["Tel"] = admin.Tel;

			if (dt.Rows.Count == 0)
			{
				dt.Rows.Add(row);
			}

			SqlConnection conn = CMMgr.GetConnection();
			using (sa = new SqlDataAdapter("SELECT Top 0 * FROM ml_Admin",conn))
			{
				try
				{
					builder = new SqlCommandBuilder(sa);
					sa.Update(dt);
					returnValue = true;
				}
				catch (SqlException err)
				{
					
				}
				catch (Exception err)
				{
					
				}
				finally
				{
					conn.Close();
					conn.Dispose();
				}
			}
		}
		return returnValue;
	}
	#endregion

	#region������GetAdmin | ��ȡAdmin��Ϣ
	/// <summary>
	/// ��ȡһ��Admin����Ϣ
	/// </summary>
	/// <param name="adminID">��¼���</param>
	/// <returns>һ��Admin���¼</returns>
	public Admin GetAdmin(string AdminID)
	{
		Admin Admin = new Admin();
		string strSQL = "SELECT * FROM ml_Admin WHERE AdminID = '" + AdminID + "'";
		DataTable dt = CMMgr.GetDataTable(strSQL);
		if (dt.Rows.Count > 0)
		{
			DataRow row = dt.Rows[0];
			Admin.Password = row["Password"].ToString();
			Admin.AdminID = row["AdminID"].ToString();
            Admin.UserName = row["UserName"].ToString();
            Admin.Tel = row["Tel"].ToString();
		}
        return Admin;

    }
    #endregion

    #region������DelAdmin | ɾ��Admin��Ϣ
    /// <summary>
	/// ɾ��Admin����Ϣ
	/// </summary>
	/// <param name="AdminID">��¼��Ų���</param>
	public void DelAdmin(string AdminID)
	{
		string strSQL = "DELETE FROM ml_Admin WHERE AdminID = '" + AdminID + "'";
		CMMgr.ExecuteNonQuery(strSQL);
	}

	/// <summary>
	/// ɾ��Admin����Ϣ
	/// </summary>
	/// <param name="Admin">Admin��</param>
	public void DelAdmin(Admin admin)
	{
		this.DelAdmin(admin.AdminID);
	}
	#endregion

    #region ����GetAdminList | ��ȡ����Ա�б���Ϣ
    /// <summary>
    /// ����GetAdminList | ��ȡ����Ա�б���Ϣ
    /// </summary>
    /// <returns>��������Ա���б���Ϣ</returns>
    public DataTable GetAdminList()
    {
        return CMMgr.GetDataTable("SELECT * FROM ml_Admin");
    }
    #endregion
}