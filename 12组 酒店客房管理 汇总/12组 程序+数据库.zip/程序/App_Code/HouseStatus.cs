using System;

/// <summary>
/// ����״̬
/// </summary>
public class HouseStatus
{
	private int m_HouseStatusID;
	private string m_HouseStatusName;

	/// <summary>
	/// ����״̬
	/// </summary>
	public HouseStatus()
	{
		this.m_HouseStatusID = 0;
		this.m_HouseStatusName = "";
	}

	/// <summary>
	/// ���
	/// </summary>
	public int HouseStatusID
	{
		set
		{
			this.m_HouseStatusID = value;
		}
		get
		{
			return this.m_HouseStatusID;
		}
	}

	/// <summary>
	/// ����
	/// </summary>
	public string HouseStatusName
	{
		set
		{
			this.m_HouseStatusName = value;
		}
		get
		{
			return this.m_HouseStatusName;
		}
	}
}
