using System;

/// <summary>
/// ������
/// </summary>
public class House
{
	private string m_HouseID;
	private string m_HouseName;
    private int m_Price;
    private HouseType m_HouseType;
    private HouseStatus m_HouseStatus;

	/// <summary>
	/// ������
	/// </summary>
	public House()
	{
		this.m_HouseID = "";
		this.m_HouseName = "";
        this.m_Price = 0;
        this.m_HouseType = new HouseType();
        this.m_HouseStatus = new HouseStatus();
	}

	/// <summary>
	/// ���
	/// </summary>
	public string HouseID
	{
		set
		{
			this.m_HouseID = value;
		}
		get
		{
			return this.m_HouseID;
		}
	}

	/// <summary>
	/// �����˵��
	/// </summary>
	public string HouseName
	{
		set
		{
			this.m_HouseName = value;
		}
		get
		{
			return this.m_HouseName;
		}
	}

    /// <summary>
    /// ����۸�
    /// </summary>
    public int Price
    {
        set
        {
            this.m_Price = value;
        }
        get
        {
            return this.m_Price;
        }
    }
  
    /// <summary>
    /// ����
    /// </summary>
    public HouseType HouseType
    {
        set
        {
            this.m_HouseType = value;
        }
        get
        {
            return this.m_HouseType;
        }
    }

    /// <summary>
    /// ״̬
    /// </summary>
    public HouseStatus HouseStatus
    {
        set
        {
            this.m_HouseStatus = value;
        }
        get
        {
            return this.m_HouseStatus;
        }
    }
}