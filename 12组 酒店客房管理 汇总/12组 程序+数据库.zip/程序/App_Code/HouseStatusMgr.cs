using System;
using System.Data;
using System.Data.SqlClient;

/// <summary>
/// HouseStatus������
/// </summary>
public class HouseStatusMgr
{
	/// <summary>
	/// ��ʼ��������
	/// </summary>
	public HouseStatusMgr()
	{
	}

	#region������UpdateHouseStatus | ����HouseStatus��Ϣ
	/// <summary>
	/// ����HouseStatus����Ϣ
	/// </summary>
	/// <param name="houseStatus">����״̬����</param>
	/// <returns>���³ɹ�����true ���򷵻�false</returns>
	public bool UpdateHouseStatus(HouseStatus houseStatus)
	{
		string strSQL = "";
		SqlDataAdapter sa = null;
		SqlCommandBuilder builder = null;
		DataRow row = null;
		DataTable dt = null;
		bool returnValue = false;
		if (houseStatus != null)
		{
			if (houseStatus.HouseStatusID == 0)
			{
				strSQL = "SELECT Top 0 * FROM ml_HouseStatus";
			}
			else
			{
				strSQL = "SELECT * FROM ml_HouseStatus WHERE HouseStatusID = '" + houseStatus.HouseStatusID + "'";
			}

			dt = CMMgr.GetDataTable(strSQL);

			if (dt.Rows.Count > 0)
			{
				row = dt.Rows[0];
			}
			else
			{
				row = dt.NewRow();
			}

			row["HouseStatusName"] = houseStatus.HouseStatusName;

			if (dt.Rows.Count == 0)
			{
				dt.Rows.Add(row);
			}

			SqlConnection conn = CMMgr.GetConnection();
			using (sa = new SqlDataAdapter("SELECT Top 0 * FROM ml_HouseStatus",conn))
			{
                try
                {
                    builder = new SqlCommandBuilder(sa);
                    sa.Update(dt);
                    returnValue = true;
                }
                catch { }
				finally
				{
					conn.Close();
					conn.Dispose();
				}
			}
		}
		return returnValue;
	}
	#endregion

	#region������GetHouseStatus | ��ȡHouseStatus��Ϣ
	/// <summary>
	/// ��ȡһ��HouseStatus����Ϣ
	/// </summary>
	/// <param name="HouseStatusID">���</param>
	/// <returns>һ��HouseStatus���¼</returns>
	public HouseStatus GetHouseStatus(string HouseStatusID)
	{
		HouseStatus houseStatus = new HouseStatus();
		string strSQL = "SELECT * FROM ml_HouseStatus WHERE HouseStatusID = '" + HouseStatusID + "'";
		DataTable dt = CMMgr.GetDataTable(strSQL);
		if (dt.Rows.Count > 0)
		{
			DataRow row = dt.Rows[0];
			houseStatus.HouseStatusID = int.Parse(row["HouseStatusID"].ToString());
			houseStatus.HouseStatusName = row["HouseStatusName"].ToString();
			return houseStatus;
		}
		else
		{
			return houseStatus;
		}
	}

	/// <summary>
	/// ��ȡһ��HouseStatus����Ϣ
	/// </summary>
	/// <param name="HouseStatusID">���</param>
	/// <returns>һ��HouseStatus���¼</returns>
	public HouseStatus GetHouseStatus(int HouseStatusID)
	{
		return GetHouseStatus(HouseStatusID.ToString());
	}

	#endregion

	#region������DelHouseStatus | ɾ��HouseStatus��Ϣ
	/// <summary>
	/// ɾ��HouseStatus����Ϣ
	/// </summary>
	/// <param name="HouseStatusID">��Ų���</param>
	public void DelHouseStatus(string HouseStatusID)
	{
		string strSQL = "DELETE FROM ml_HouseStatus WHERE HouseStatusID = '" + HouseStatusID + "'";
		CMMgr.ExecuteNonQuery(strSQL);
	}

	/// <summary>
	/// ɾ��HouseStatus����Ϣ
	/// </summary>
	/// <param name="HouseStatusID">���</param>
	public void DelHouseStatus(int HouseStatusID)
	{
		this.DelHouseStatus(HouseStatusID.ToString());
	}

	/// <summary>
	/// ɾ��HouseStatus����Ϣ
	/// </summary>
	/// <param name="houseStatus">HouseStatus��</param>
	public void DelHouseStatus(HouseStatus houseStatus)
	{
		this.DelHouseStatus(houseStatus.HouseStatusID);
	}
	#endregion

    #region ����GetHouseStatusList |����ȡHouseStatus�б���Ϣ
    /// <summary>
    /// ����GetHouseStatusList |����ȡHouseStatus�б���Ϣ
    /// </summary>
    /// <returns></returns>
    public DataTable GetHouseStatusList()
    {
        return CMMgr.GetDataTable("SELECT * FROM ml_HouseStatus");
    }
    #endregion
}
