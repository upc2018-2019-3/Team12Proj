using System;
using System.Data;
using System.Data.SqlClient;


/// <summary>
/// House������
/// </summary>
public class HouseMgr
{
	/// <summary>
	/// ��ʼ��������
	/// </summary>
	public HouseMgr()
	{
	}

	#region������UpdateHouse | ����House��Ϣ
	/// <summary>
	/// ����House����Ϣ
	/// </summary>
	/// <param name="house">���������</param>
	/// <returns>���³ɹ�����true ���򷵻�false</returns>
	public bool UpdateHouse(House house)
	{
		string strSQL = "";
		SqlDataAdapter sa = null;
		SqlCommandBuilder builder = null;
		DataRow row = null;
		DataTable dt = null;
		bool returnValue = false;
		if (house != null)
		{
			if (house.HouseID == "")
			{
				strSQL = "SELECT Top 0 * FROM ml_House";
			}
			else
			{
				strSQL = "SELECT * FROM ml_House WHERE HouseID = '" + house.HouseID + "'";
			}

			dt = CMMgr.GetDataTable(strSQL);

			if (dt.Rows.Count > 0)
			{
				row = dt.Rows[0];
			}
			else
			{
				row = dt.NewRow();
				row["HouseID"] = house.HouseID;
                row["HouseName"] = house.HouseName;
                row["Price"] = house.Price;
                row["HouseTypeID"] = house.HouseType.HouseTypeID;
			}
		
            row["HouseStatusID"] = house.HouseStatus.HouseStatusID;

			if (dt.Rows.Count == 0)
			{
				dt.Rows.Add(row);
			}

			SqlConnection conn = CMMgr.GetConnection();
			using (sa = new SqlDataAdapter("SELECT Top 0 * FROM ml_House",conn))
			{
				try
				{
					builder = new SqlCommandBuilder(sa);
					sa.Update(dt);
					returnValue = true;
				}
				catch (SqlException err)
				{
					
				}
				catch (Exception err)
				{
					
				}
				finally
				{
					conn.Close();
					conn.Dispose();
				}
			}
		}
		return returnValue;
	}
	#endregion

	#region������GetHouse | ��ȡHouse��Ϣ
	/// <summary>
	/// ��ȡһ��House����Ϣ
	/// </summary>
	/// <param name="houseID">��¼���</param>
	/// <returns>һ��House���¼</returns>
	public House GetHouse(string HouseID)
	{
		House house = new House();
        HouseTypeMgr htMgr = new HouseTypeMgr();
        HouseStatusMgr hsMgr = new HouseStatusMgr();
		string strSQL = "SELECT * FROM ml_House WHERE HouseID = '" + HouseID + "'";
		DataTable dt = CMMgr.GetDataTable(strSQL);
		if (dt.Rows.Count > 0)
		{
			DataRow row = dt.Rows[0];
            house.HouseID = row["HouseID"].ToString();
			house.HouseName = row["HouseName"].ToString();
            house.Price = int.Parse(row["Price"].ToString());
            house.HouseType = htMgr.GetHouseType(row["HouseTypeID"].ToString());
            house.HouseStatus = hsMgr.GetHouseStatus(row["HouseStatusID"].ToString());
		}
        return house;

    }
    #endregion

    #region������DelHouse | ɾ��House��Ϣ
    /// <summary>
	/// ɾ��House����Ϣ
	/// </summary>
	/// <param name="HouseID">��¼��Ų���</param>
	public void DelHouse(string HouseID)
	{
		string strSQL = "DELETE FROM ml_House WHERE HouseID = '" + HouseID + "'";
		CMMgr.ExecuteNonQuery(strSQL);
	}

	/// <summary>
	/// ɾ��House����Ϣ
	/// </summary>
	/// <param name="House">House��</param>
	public void DelHouse(House house)
	{
		this.DelHouse(house.HouseID);
	}
	#endregion

    #region ����GetHouseList | ��ȡ�����б���Ϣ
    /// <summary>
    /// ����GetHouseList | ��ȡ�����б���Ϣ
    /// </summary>
    /// <param name="HouseID">����</param>
    /// <param name="HouseStatusID">����</param>
    /// <param name="HouseTypeID">״̬</param>
    /// <returns>����������б���Ϣ</returns>
    public DataTable GetHouseList(string HouseID,int HouseTypeID,int HouseStatusID)
    {
        string strSQL = "SELECT *,(SELECT HouseTypeName FROM ml_HouseType WHERE HouseTypeID = ml_House.HouseTypeID) AS HouseTypeName,"
                      + "(SELECT HouseStatusName FROM ml_HouseStatus WHERE HouseStatusID = ml_House.HouseStatusID) AS HouseStatusName FROM ml_House WHERE HouseID Like '%" + HouseID + "%' ";
        if (HouseTypeID != -1)
        {
            strSQL += "AND HouseTypeID = " + HouseTypeID.ToString() + " ";
        }
        if (HouseStatusID != -1)
        {
            strSQL += "AND HouseStatusID = " + HouseStatusID.ToString() + " ";
        }
        return CMMgr.GetDataTable(strSQL);
    }
    #endregion
}