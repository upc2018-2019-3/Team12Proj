using System;

/// <summary>
/// �������
/// </summary>
public class Buy
{
	private int m_BuyID;
	private string m_PersonName;
    private string m_Card;
    private string m_Address;
    private House m_House;
    private int m_Deposit;
    private DateTime m_HouseDate;
    private DateTime m_ExitDate;
    private int m_ExitPrice;

	/// <summary>
	/// �������
	/// </summary>
	public Buy()
	{
		this.m_BuyID = 0;
		this.m_PersonName = "";
        this.m_Card = "";
        this.m_Address = "";
        this.m_House = new House();
        this.m_Deposit = 0;
        this.m_HouseDate = DateTime.Now;
        this.m_ExitDate = DateTime.Parse("1950-1-1");
        this.m_ExitPrice = 0;
	}

	/// <summary>
	/// ���
	/// </summary>
	public int BuyID
	{
		set
		{
			this.m_BuyID = value;
		}
		get
		{
			return this.m_BuyID;
		}
	}

	/// <summary>
	/// ��ס������
	/// </summary>
	public string PersonName
	{
		set
		{
			this.m_PersonName = value;
		}
		get
		{
			return this.m_PersonName;
		}
	}

    /// <summary>
    /// ��ס������֤��
    /// </summary>
    public string Card
    {
        set
        {
            this.m_Card = value;
        }
        get
        {
            return this.m_Card;
        }
    }

    /// <summary>
    /// ��ס�˵�ַ
    /// </summary>
    public string Address
    {
        set
        {
            this.m_Address = value;
        }
        get
        {
            return this.m_Address;
        }
    }

    /// <summary>
    /// ����
    /// </summary>
    public House House
    {
        set
        {
            this.m_House = value;
        }
        get
        {
            return this.m_House;
        }
    }

    /// <summary>
    /// Ѻ��
    /// </summary>
    public int Deposit
    {
        set
        {
            this.m_Deposit = value;
        }
        get
        {
            return this.m_Deposit;
        }
    }

    /// <summary>
    /// ��סʱ��
    /// </summary>
    public DateTime HouseDate
    {
        set
        {
            this.m_HouseDate = value;
        }
        get
        {
            return this.m_HouseDate;
        }
    }

    /// <summary>
    /// �˷�ʱ��
    /// </summary>
    public DateTime ExitDate
    {
        set
        {
            this.m_ExitDate = value;
        }
        get
        {
            return this.m_ExitDate;
        }
    }

    /// <summary>
    /// �˻�Ѻ��
    /// </summary>
    public int ExitPrice
    {
        set
        {
            this.m_ExitPrice = value;
        }
        get
        {
            return this.m_ExitPrice;
        }
    }
}
