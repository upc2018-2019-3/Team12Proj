using System;

/// <summary>
/// ��������
/// </summary>
public class HouseType
{
	private int m_HouseTypeID;
	private string m_HouseTypeName;

	/// <summary>
	/// ��������
	/// </summary>
	public HouseType()
	{
		this.m_HouseTypeID = 0;
		this.m_HouseTypeName = "";
	}

	/// <summary>
	/// ���
	/// </summary>
	public int HouseTypeID
	{
		set
		{
			this.m_HouseTypeID = value;
		}
		get
		{
			return this.m_HouseTypeID;
		}
	}

	/// <summary>
	/// ����
	/// </summary>
	public string HouseTypeName
	{
		set
		{
			this.m_HouseTypeName = value;
		}
		get
		{
			return this.m_HouseTypeName;
		}
	}
}
