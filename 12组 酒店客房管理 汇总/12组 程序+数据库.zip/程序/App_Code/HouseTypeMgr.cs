using System;
using System.Data;
using System.Data.SqlClient;

/// <summary>
/// HouseType������
/// </summary>
public class HouseTypeMgr
{
	/// <summary>
	/// ��ʼ��������
	/// </summary>
	public HouseTypeMgr()
	{
	}

	#region������UpdateHouseType | ����HouseType��Ϣ
	/// <summary>
	/// ����HouseType����Ϣ
	/// </summary>
	/// <param name="houseType">�������Ͳ���</param>
	/// <returns>���³ɹ�����true ���򷵻�false</returns>
	public bool UpdateHouseType(HouseType houseType)
	{
		string strSQL = "";
		SqlDataAdapter sa = null;
		SqlCommandBuilder builder = null;
		DataRow row = null;
		DataTable dt = null;
		bool returnValue = false;
		if (houseType != null)
		{
			if (houseType.HouseTypeID == 0)
			{
				strSQL = "SELECT Top 0 * FROM ml_HouseType";
			}
			else
			{
				strSQL = "SELECT * FROM ml_HouseType WHERE HouseTypeID = '" + houseType.HouseTypeID + "'";
			}

			dt = CMMgr.GetDataTable(strSQL);

			if (dt.Rows.Count > 0)
			{
				row = dt.Rows[0];
			}
			else
			{
				row = dt.NewRow();
			}

			row["HouseTypeName"] = houseType.HouseTypeName;

			if (dt.Rows.Count == 0)
			{
				dt.Rows.Add(row);
			}

			SqlConnection conn = CMMgr.GetConnection();
			using (sa = new SqlDataAdapter("SELECT Top 0 * FROM ml_HouseType",conn))
			{
                try
                {
                    builder = new SqlCommandBuilder(sa);
                    sa.Update(dt);
                    returnValue = true;
                }
                catch { }
				finally
				{
					conn.Close();
					conn.Dispose();
				}
			}
		}
		return returnValue;
	}
	#endregion

	#region������GetHouseType | ��ȡHouseType��Ϣ
	/// <summary>
	/// ��ȡһ��HouseType����Ϣ
	/// </summary>
	/// <param name="HouseTypeID">���</param>
	/// <returns>һ��HouseType���¼</returns>
	public HouseType GetHouseType(string HouseTypeID)
	{
		HouseType houseType = new HouseType();
		string strSQL = "SELECT * FROM ml_HouseType WHERE HouseTypeID = '" + HouseTypeID + "'";
		DataTable dt = CMMgr.GetDataTable(strSQL);
		if (dt.Rows.Count > 0)
		{
			DataRow row = dt.Rows[0];
			houseType.HouseTypeID = int.Parse(row["HouseTypeID"].ToString());
			houseType.HouseTypeName = row["HouseTypeName"].ToString();
			return houseType;
		}
		else
		{
			return houseType;
		}
	}

	/// <summary>
	/// ��ȡһ��HouseType����Ϣ
	/// </summary>
	/// <param name="HouseTypeID">���</param>
	/// <returns>һ��HouseType���¼</returns>
	public HouseType GetHouseType(int HouseTypeID)
	{
		return GetHouseType(HouseTypeID.ToString());
	}

	#endregion

	#region������DelHouseType | ɾ��HouseType��Ϣ
	/// <summary>
	/// ɾ��HouseType����Ϣ
	/// </summary>
	/// <param name="HouseTypeID">��Ų���</param>
	public void DelHouseType(string HouseTypeID)
	{
		string strSQL = "DELETE FROM ml_HouseType WHERE HouseTypeID = '" + HouseTypeID + "'";
		CMMgr.ExecuteNonQuery(strSQL);
	}

	/// <summary>
	/// ɾ��HouseType����Ϣ
	/// </summary>
	/// <param name="HouseTypeID">���</param>
	public void DelHouseType(int HouseTypeID)
	{
		this.DelHouseType(HouseTypeID.ToString());
	}

	/// <summary>
	/// ɾ��HouseType����Ϣ
	/// </summary>
	/// <param name="houseType">HouseType��</param>
	public void DelHouseType(HouseType houseType)
	{
		this.DelHouseType(houseType.HouseTypeID);
	}
	#endregion

    #region ����GetHouseTypeList |����ȡHouseType�б���Ϣ
    /// <summary>
    /// ����GetHouseTypeList |����ȡHouseType�б���Ϣ
    /// </summary>
    /// <returns></returns>
    public DataTable GetHouseTypeList()
    {
        return CMMgr.GetDataTable("SELECT * FROM ml_HouseType");
    }
    #endregion
}
