﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Buy_List : WebPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        this.ValidatePopedom("管理员"); 
        if (!this.IsPostBack)
        {
            this.InitList();
            this.initForm();
        }
    }

    #region 窗体内部函数
    private void InitList()
    {
        HouseMgr mgr = new HouseMgr();
        this.lstHouseID.DataSource = mgr.GetHouseList("",-1,-1);
        this.lstHouseID.DataTextField = "HouseName";
        this.lstHouseID.DataValueField = "HouseID";
        this.lstHouseID.DataBind();
        this.lstHouseID.Items.Insert(0, new ListItem("全部房间", "-1"));
    }
    /// <summary>
    /// 初始化列表信息
    /// </summary>
    private void initForm()
    {
        BuyMgr mgr = new BuyMgr();
        this.dgList.DataSource = mgr.GetNoExitBuyList(int.Parse(this.lstHouseID.SelectedValue));
        this.dgList.DataBind();
    }
    #endregion

    #region 事件产生的函数

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        this.initForm();
    }

    #endregion

    protected void dgList_PageIndexChanged(object source, DataGridPageChangedEventArgs e)
    {
        this.dgList.CurrentPageIndex = e.NewPageIndex;
        this.initForm();
    }

    protected void dgList_DeleteCommand(object source, DataGridCommandEventArgs e)
    {
        BuyMgr mgr = new BuyMgr();
        mgr.DelBuy(((HiddenField)e.Item.FindControl("hidBuyID")).Value);
        this.initForm();
    }
}
