﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;

public partial class Buy_Edit : WebPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        this.ValidatePopedom("管理员"); ;       
        if (!this.IsPostBack)
        {
            this.hidBuyID.Value = Request.QueryString["BuyID"] + "";
            this.initForm();
        }
    }

    #region 事件产生的函数
    protected void btnOK_Click(object sender, EventArgs e)
    {
        BuyMgr mgr = new BuyMgr();
        Buy buy = new Buy();
        if (this.hidBuyID.Value != "")
        {
            buy = mgr.GetBuy(this.hidBuyID.Value);
        }
        buy.ExitDate = DateTime.Now;
        buy.ExitPrice = int.Parse(this.txtExitPrice.Text);        
        mgr.UpdateBuy(buy);
        buy.House.HouseStatus.HouseStatusID = 1;
        HouseMgr hMgr = new HouseMgr();
        hMgr.UpdateHouse(buy.House);
        this.SendMessage("信息编辑成功");
        this.WriteJavaScript("jav", "window.location='Buy_List.aspx'");

    }
    #endregion

    #region 窗体内部函数

    /// <summary>
    /// 初始化信息
    /// </summary>
    private void initForm()
    {
        HouseMgr hMgr = new HouseMgr();
        BuyMgr mgr = new BuyMgr();
        Buy buy = mgr.GetBuy(this.hidBuyID.Value);
        House house = hMgr.GetHouse(buy.House.HouseID.ToString());

        this.txtAddress.Text = buy.Address;
        this.txtCard.Text = buy.Card;
        this.txtDeposit.Text = buy.Deposit.ToString();
        this.txtHouseID.Text = buy.House.HouseID;
        this.txtPersonName.Text = buy.PersonName;

        DateTime   dt1   =   buy.HouseDate;
        DateTime   dt2   =   DateTime.Now;
        TimeSpan   ts   =   dt2-dt1;

        this.txtBuyPrice.Text = (Math.Abs(ts.Days) * house.Price).ToString();
        this.txtExitPrice.Text = (buy.Deposit - int.Parse(this.txtBuyPrice.Text)).ToString();

    }
    #endregion

}
