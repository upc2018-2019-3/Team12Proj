﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;

public partial class Admin_Edit : WebPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        this.ValidatePopedom("管理员");
        if (!this.IsPostBack)
        {
            this.txtAdminID.Text = Request.QueryString["AdminID"] + "";
            if (this.txtAdminID.Text != "")
            {
                this.txtAdminID.Enabled = false;
            }
            this.initForm();
        }
    }

    #region 事件产生的函数
    protected void btnOK_Click(object sender, EventArgs e)
    {
        if (this.ValidateData())
        {
            Admin admin = new Admin();
            AdminMgr mgr = new AdminMgr();
            if (this.txtAdminID.Enabled == false)
            {
                admin = mgr.GetAdmin(this.txtAdminID.Text.Trim());
            }
            else
            {
                admin.AdminID = this.txtAdminID.Text.Trim();
            }
            admin.UserName = this.txtUserName.Text;
            admin.Tel = this.txtTel.Text;
            admin.Password = this.txtPassword.Text;


            mgr.UpdateAdmin(admin);
            this.SendMessage("信息编辑成功");
            if (this.txtAdminID.Enabled)
            {
                this.ClearTextData(this);
            }
        }
    }
    #endregion

    #region 窗体内部函数
    /// <summary>
    /// 初始化窗体信息
    /// </summary>
    private void initForm()
    {
        if (!this.txtAdminID.Enabled)
        {
            AdminMgr mgr = new AdminMgr();
            Admin admin = mgr.GetAdmin(this.txtAdminID.Text);
            if (admin.AdminID == "")
            {
                this.btnOK.Enabled = false;
                this.SendMessage("没有找到该管理员");
            }
            else
            {
                this.txtAdminID.Text = admin.AdminID;
                this.txtAdminID.Enabled = false;
                this.txtUserName.Text = admin.UserName;
                this.txtTel.Text = admin.Tel;
                this.txtPassword.Text = admin.Password;
            }
        }
    }

    /// <summary>
    /// 验证添加的管理员信息
    /// </summary>
    /// <returns>可以提交返回true否则返回false</returns>
    private bool ValidateData()
    {
        if (this.txtAdminID.Enabled == true)
        {
            AdminMgr mgr = new AdminMgr();
            if (mgr.GetAdmin(this.txtAdminID.Text).AdminID != "")
            {
                this.SendMessage("该登录名已存在");
                return false;
            }
        }
        return true;
    }
    #endregion

}
