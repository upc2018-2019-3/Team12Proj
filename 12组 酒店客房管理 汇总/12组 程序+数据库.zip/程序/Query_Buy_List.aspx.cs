﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Query_Buy_List : WebPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        this.ValidatePopedom("管理员"); 
        if (!this.IsPostBack)
        {
            this.txtEndDate.Text = this.txtStartDate.Text = DateTime.Now.ToShortDateString();
            this.initForm();
        }
    }

    #region 窗体内部函数
    /// <summary>
    /// 初始化列表信息
    /// </summary>
    private void initForm()
    {
        BuyMgr mgr = new BuyMgr();
        this.dgList.DataSource = mgr.GetBuyList(DateTime.Parse(this.txtStartDate.Text), DateTime.Parse(this.txtEndDate.Text));
        this.dgList.DataBind();

        this.lblSum.Text = mgr.GetBuySumPrice(DateTime.Parse(this.txtStartDate.Text), DateTime.Parse(this.txtEndDate.Text)) + "元";
    }
    #endregion

    protected void dgList_PageIndexChanged(object source, DataGridPageChangedEventArgs e)
    {
        this.dgList.CurrentPageIndex = e.NewPageIndex;
        this.initForm();
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        this.initForm();
    }
    protected void dgList_ItemDataBound(object sender, DataGridItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.AlternatingItem || e.Item.ItemType == ListItemType.Item)
        {
            if (e.Item.Cells[4].Text.StartsWith("1950"))
            {
                e.Item.Cells[4].Text = "";
            }
        }
    }
}
